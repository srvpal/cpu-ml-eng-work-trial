# Work trial submission

Name: Sourav Pal
Time spent (minutes): 50

**Bottom line:** the author says the task is ready to ship. It is not. I found six BLOCKERs:
five ways to get 1.0 without doing the work, and one way a correct fix scores 0.0. Each one is
shown with a control I ran. The author's main claim, "Recovery is therefore enforced", is false:
deploying twice skips the injected failure and still scores 1.0 (F1, fixed and proven in Part B).

All numbers below are from runs on a fresh extract of `cpu-ml-eng-work-trial-updated.zip`
(Python 3.12.10, numpy 2.5.3, scikit-learn 1.9.1). Raw output is in `evidence/`.

Reference accuracies on the hidden live stream (228 rows, 143 benign / 85 malignant):

| policy | live accuracy |
|---|---|
| gold (`solution/fixed_serve.py`) | 0.9825 |
| other correct fixes (LR+RobustScaler / SVC / kNN / RF raw / GBM raw) | 0.9825 / 0.9737 / 0.9693 / 0.9649 / 0.9561 |
| one-feature rule `mean_area < 705.6` (fit on `train.csv`) | 0.8991 |
| **always "benign" (no skill)** | **0.6272** |
| shipped broken release | 0.6096 |
| **`BAR` / `pass_bar_accuracy`** | **0.62** |

## Part A: Findings (most severe first)

All six are BLOCKERs, so the order among them is a judgment call. I ranked them by how easily a
policy gets the wrong reward. F1 to F3 happen to an agent that only edits `pipeline/` and calls
the sanctioned ops. F4 needs one read of a file the service itself drops into the workspace. F5
and F6 need deliberate tampering. **F5 and F6 are still the deepest problems:** each defeats
every grader-only fix, including my own patch.

### F1 - Recovery is not enforced: a second deploy wipes out the injected fault, and `strict_pass` ignores `forced_recovery_ok`
- **Severity:** BLOCKER (something that is not a properly driven fix scores 1.0)
- **Where:**
  - `task/tests/grade.py:84`: `strict_pass = terminal and walk`. `recovery` is computed at `:77` and printed at `:90`, but never used.
  - `task/workspace/env_cli.py:159`: the fault fires only when `n == inject_fault_on_deploy` (1).
  - `env_cli.py:151-156`: every deploy wipes `.envstate/deployed` and copies it fresh from the workspace.
  - The false claim is in `task/AUTHOR_NOTES.md` ("Recovery is therefore enforced").
- **Failure scenario:** `reproduce -> (apply fix) -> deploy -> deploy -> validate -> promote -> submit`.
  Deploy #2 replaces the truncated `model.pkl` before any validate runs, so the first validate is
  `clean`. There is no `FAILED`, no `diagnostics.read` and no `recovery.apply`, yet the reward is
  1.0. This path is also shorter than gold (one validate instead of two), so RL will prefer it.
  An honest agent can also hit it by accident, simply by redeploying after a second edit.
- **Evidence (ran):** `run_controls.py task/controls/nc_double_deploy.py` gave **1.0**
  (`forced_recovery_ok: false`, `terminal_accuracy: 0.9825`). With the patch below it gives **0.0**, and gold stays at 1.0.
- **Fix:**
  - Grader: `strict_pass = terminal and walk and recovery` (this submission's patch).
  - Environment: keep injecting the fault until a `rebuild_artifact` recovery has been applied (`env_cli.py:159`), so an agent that redeploys still meets the fault instead of getting stuck at 0.0. I verified this: see Part B.

### F2 - The terminal bar (0.62) is below the majority-class baseline, so a constant predictor scores 1.0
- **Severity:** BLOCKER (a policy with no skill scores 1.0)
- **Where:** `task/tests/grade.py:22` (`BAR = 0.62`) and `task/setup.py:62` (`pass_bar_accuracy: 0.62`, which `validate` uses).
- **Failure scenario:** `predict = lambda X: np.ones(len(X))` ("always benign") scores 143/228 = **0.6272 ≥ 0.62**.
  `validate` says `clean`, and the full trajectory (recovery included) passes. The bar was set
  "between broken (0.610) and gold (0.982)", but the broken release is itself *worse than a
  constant*. The bar therefore separates "broken" from "not broken", not "fixed" from "no skill".
- **Evidence (ran):** `nc_majority_class.py` gave **1.0** before the patch and **1.0** after it (F1's patch does not touch this).
- **Fix:** set `BAR = pass_bar_accuracy = 0.93`, from a single source (`grade.py` should read
  `service/config.json`). 0.93 is above the one-feature rule (0.899) and below every correct fix I
  tried (≥ 0.956). **Verified:** `nc_majority_class` gives 0.0 and gold gives 1.0
  (`evidence/optional_f2_f3_fixes.log`). Also consider a minimum per-batch accuracy, since the bug
  is per-batch.

### F3 - A correct but different fix scores 0.0: the grader stages only `serve.py` + `artifacts/`, while `validate` runs the whole release
- **Severity:** BLOCKER (a correct, properly driven fix scores 0.0)
- **Where:**
  - `task/tests/grade.py:63-65`: copies only `pipeline/serve.py` and `artifacts/`, then imports the candidate with the grader's working directory.
  - `env_cli.py:154-155`: deploy snapshots `pipeline/`, `artifacts/` and `data/`.
  - `env_cli.py:99`: validate runs the snapshot with `cwd=<release root>`.
- **Failure scenario:** the agent standardises with `data/train_stats.json`. `train.py` writes that
  file, `instruction.md` points to it, and it is numerically identical to `scaler.pkl`. The agent
  then drives the full trajectory: validate `clean`, promote, submit. The grader fails with
  `FileNotFoundError: .../data/train_stats.json` and the reward is 0.0. The same thing happens to
  any fix that imports a helper module from `pipeline/` or opens artifacts by relative path.
- **Evidence (ran):** `pc_train_stats_serve.py` (a positive control that should score 1.0) gave **0.0** before and after the patch.
- **Fix:** grade exactly what validate ran: stage the whole deployed tree and run it the way
  validate does (a subprocess with `cwd=root`). **Verified:** the one-line change
  `shutil.copytree(deployed, root, dirs_exist_ok=True)` makes this control score 1.0.

### F4 - `validate` copies the hidden live stream, labels included, into the agent's workspace
- **Severity:** BLOCKER (a policy that reads answers it should not have scores 1.0)
- **Where:** `task/workspace/env_cli.py:174-179`. This runs *before* the health check at `:181`, so even the first `FAILED` validate leaks the data.
- **Failure scenario:** after the first validate, `.envstate/cache/stream.npz` holds `X` and `y`
  for all 228 live rows. The agent ships them as a lookup table (no model), does the proper
  recovery, redeploys, validates, promotes and submits. It scores accuracy 1.0000 (above gold's
  0.9825, which is itself a sign of leakage) and reward 1.0. There is a second problem in the same
  place: `if not cache.exists()` means the agent can plant its own `stream.npz` beforehand, and
  then `validate` says `clean` for anything. That makes the validate gate forgeable through a
  sanctioned op.
- **Evidence (ran):** `nc_label_leak.py` gave **1.0** before and **1.0** after the patch.
- **Fix:** delete the cache. The stream should only ever be read in the service process, from
  `service/`, and only the clean/dirty bit should be returned.

### F5 - The trust root is agent-writable: forging the action log and the deployed release scores 1.0 with no ops at all
- **Severity:** BLOCKER (a policy that fabricates what the verifier checks scores 1.0; this also defeats F1's patch)
- **Where:**
  - The grader trusts two files in the workspace: `task/tests/grade.py:30-34` (`WS/.envstate/actions.jsonl`) and `:60` (`WS/.envstate/deployed`).
  - The ops service keeps all its state in the workspace: `env_cli.py:23-27`. That includes the validate budget, which is counted from lines of that log (`:171`).
  - `env_cli.py` itself lives in `workspace/`, so the agent can edit the gate.
  - The isolation model contradicts itself. `env_cli.py` runs as the agent, yet it reads the root-only `service/` directory (`:28-29`, `:178`). Either the agent can read `service/`, or the ops service cannot run.
- **Failure scenario:** without ever running `env_cli.py`, the agent writes the 8-line gold
  trajectory into `.envstate/actions.jsonl`, including the `FAILED` validate and the
  `rebuild_artifact` recovery. It then copies a release into `.envstate/deployed/`. The reward is
  1.0. The same access also allows unlimited validates (delete the log to reset the budget), and
  lets the agent turn off fault injection by editing `env_cli.py`. This directly refutes
  the claim made by the author's `nc_one_shot` control ("a correct fix without the trajectory cannot score").
- **Evidence (ran):** `nc_forged_log.py` gave **1.0** before and **1.0** after the patch.
- **Fix:** the ops service must be a separate privileged process, for example a root daemon
  behind a socket. Its log, deployed snapshot, stream and budget must live on the service side.
  The grader should read state only from there. At minimum, the service should HMAC-sign each log
  entry and the deploy snapshot's hash with a key kept in `service/`, and the grader should verify
  both.

### F6 - The verifier imports agent code into its own process, so the candidate can rewrite its own reward
- **Severity:** BLOCKER (a policy that tampers with the verifier scores 1.0; this also defeats F1's patch)
- **Where:** `task/tests/grade.py:66-69`. It runs `spec.loader.exec_module(mod)` on `.envstate/deployed/pipeline/serve.py`, inside the verifier's own interpreter (root in production).
- **Failure scenario:** the candidate `serve.py` checks `__main__.REWARD_DIR` and registers an
  `atexit` hook that writes `1.0` to `reward.txt` after `grade.py` has written its own verdict. It
  could instead read `__main__.HIDDEN_Y`, or set `__main__.BAR = 0`. The model always predicts
  "malignant" (0.3728), and the trajectory stops at `deploy`: no validate, no recovery, no
  promote, no submit. The grader prints `"reward": 0.0`, but `reward.txt`, which is what the
  harness reads, says **1.0**. So the verifier's own log lies.
- **Evidence (ran):** `nc_grader_hijack.py` gave **1.0** before and **1.0** after the patch.
- **Fix:** never import candidate code into the verifier. Score it in a subprocess, with a
  timeout, as an unprivileged user that has no access to `service/`, `tests/` or `REWARD_DIR`.
  Reuse `env_cli.run_candidate`: pass `X` in through a file and read the predictions back.

### Also noted (below F6)
- **MAJOR: submit freezes nothing, and the grader grades whatever is deployed at grading time.**
  - Where: `grade.py:60`; `op_deploy` (`env_cli.py:146-150`) has no check for `submitted`.
  - Failure scenario: the agent deploys again after `submit`. The grader then scores a release that was never validated or promoted.
  - Also, `gate_walk_ok` and `forced_recovery_ok` accept a matching entry anywhere in the log, not just for the graded deploy.
  - This contradicts two lines in `instruction.md`: "submit freezes the promoted release" and "The promoted release is scored".
  - Evidence: inferred, not run.
  - Fix: record the snapshot hash at `promote`, grade that snapshot, and reject all ops after `submit`.
- **MAJOR: the author's controls are confounded, and none of them fails for a single reason.**
  - `nc_one_shot` floors only because nothing was deployed (`FileNotFoundError`, accuracy 0.0).
  - `nc_textbook` floors on the bar (0.592) and the gate walk at the same time.
  - No control exercises `forced_recovery_ok`, a no-skill baseline, or a correct-but-different fix. That is how F1 to F3 shipped with every control green.
  - Evidence (ran): the author's battery output in `evidence/before_patch.log`.
  - Fix: add every control in this submission to `BATTERY` with its expected reward.
- **MINOR: the recovery family can be brute-forced for free.**
  - Rejected calls are never logged (`env_cli.py:246-250`), and a wrong family is rejected at no cost (`:209-210`).
  - So "diagnose, then pick the matching family" tests nothing.
  - Fix: log rejected attempts and charge them against a budget.
- **MINOR: the `reproduce` gate proves little.** Running the broken code once satisfies it for the whole episode, and nothing ties it to the release that gets deployed (`env_cli.py:69-70`, `:147-149`).
- **MINOR: the `diagnostics.read` message is wrong.** It says "the deploy manifest recorded {full}" bytes, but the manifest stores a sha256. The size actually comes from the upload copy (`env_cli.py:157`, `:196-199`).
- **Long-horizon quality:**
  - The bug is visible on `serve.py:21`, where the comment gives it away.
  - `train.py`'s docstring names `scaler.pkl`.
  - The fault is one deterministic event with a single accepted family.
  - In practice this is a ~10-step script, not a long-horizon test.

## Part B: Fix + proof

- **Blocker fixed:** F1
- **Exploit control:** `task/controls/nc_double_deploy.py`
- **Patch:** `patch.diff`, one line in `task/tests/grade.py`:

```diff
-    strict_pass = terminal and walk
+    strict_pass = terminal and walk and recovery
```

Every run below uses `run_controls.py` on a fresh copy of the task. "Before" means `task/` was
identical to `task.orig/`; "after" means `task.orig/` plus `patch.diff`.

| run | before patch | after patch |
|---|---|---|
| **your exploit: `nc_double_deploy`** | **1.0** (`forced_recovery_ok: false`) | **0.0** |
| **gold (`solution/solve.py`)** | **1.0** | **1.0** |
| author battery: gold / nc_textbook / nc_one_shot | 1.0 / 0.0 / 0.0, all OK | 1.0 / 0.0 / 0.0, all OK |
| `nc_majority_class` (F2, should be 0.0) | 1.0 | 1.0, not addressed by this patch |
| `pc_train_stats_serve` (F3, should be 1.0) | 0.0 | 0.0, not addressed |
| `nc_label_leak` (F4, should be 0.0) | 1.0 | 1.0, not addressed |
| `nc_forged_log` (F5, should be 0.0) | 1.0 | 1.0, not addressed |
| `nc_grader_hijack` (F6, should be 0.0) | 1.0 (stdout says 0.0) | 1.0, not addressed |

**Gap left by a grader-only fix, and the environment fix that closes it.** With only this patch,
an honest agent that redeploys before its first validate never sees the fault, so it gets 0.0 and
has no way to recover. I verified a one-line environment fix that closes this gap. It is **not**
in `patch.diff`; see `evidence/optional_env_hardening.log`:

```diff
-    if n == CFG["inject_fault_on_deploy"]:
+    if n >= CFG["inject_fault_on_deploy"] and not any(e["op"] == "recovery.apply" for e in read_log()):
```

With this change, deploy #2 in `nc_double_deploy` is also corrupted, validate returns `FAILED`,
and the exploit scores 0.0. Gold scores 1.0 and the author's battery is all OK.

**Other fixes I verified** in a separate scratch copy (not in `patch.diff`; see
`evidence/optional_f2_f3_fixes.log`). I set `BAR = pass_bar_accuracy = 0.93` and staged the whole
deployed tree. Results: `nc_majority_class` 0.0, `pc_train_stats_serve` 1.0, gold 1.0,
`nc_double_deploy` 0.0, and the author's battery all OK.

Commands to reproduce, run from the kit root with the controls copied into `task/controls/`:

```
python3 -m venv .venv && . .venv/bin/activate && pip install numpy scikit-learn
python3 task/setup.py && cp -r task task.orig
python3 task/controls/run_controls.py task/controls/nc_double_deploy.py task/solution/solve.py   # 1.0, 1.0
python3 task/controls/run_controls.py task/controls/nc_majority_class.py task/controls/pc_train_stats_serve.py \
    task/controls/nc_label_leak.py task/controls/nc_forged_log.py task/controls/nc_grader_hijack.py   # 1.0 0.0 1.0 1.0 1.0
patch -p1 < patch.diff                        # or: git apply patch.diff
python3 task/controls/run_controls.py task/controls/nc_double_deploy.py task/solution/solve.py   # 0.0, 1.0
python3 task/controls/run_controls.py         # author battery: gold 1.0 / nc_textbook 0.0 / nc_one_shot 0.0, all OK
```

## Part C: Verdict

**Reject (send back to the author).** The task pays 1.0 for five different shortcuts:
- skipping the recovery it claims to enforce (F1)
- a constant predictor (F2)
- reading leaked labels (F4)
- a forged action log (F5)
- a candidate that rewrites its own reward (F6)

It also pays 0.0 for a correct fix that uses the training stats the task itself provides (F3).
F1 and F2 are cheap to fix. F4 to F6 are not: the isolation model is wrong at the root, because
the gate, its log, its state and the hidden stream all live in or pass through the workspace the
agent controls, and the verifier runs agent code inside its own process. The author's
"all controls green" is not evidence, because none of the controls fails for a single reason and
none of them probes the recovery term, the no-skill floor, or a correct-but-different fix.

Top priorities:
1. Move the trust root out of the workspace: the ops service should run as a separate privileged process that owns the log, the deployed snapshot, the budget and the hidden stream. Remove the `.envstate/cache` copy, and score candidates in a sandboxed subprocess, never in-process (F5, F4, F6).
2. Enforce recovery at both ends: apply this patch (`and recovery`), and make the fault persist until a `rebuild_artifact` recovery has been applied (F1, both verified).
3. Raise the bar to about 0.93, from one shared config value (F2, verified). Grade the full deployed release exactly as validate runs it (F3, verified). Freeze and grade the promoted snapshot.
4. Add every control in this submission to `BATTERY` with its expected reward, so each gate is shown to fail on its own.
