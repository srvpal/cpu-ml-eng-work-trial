"""Negative control (no skill): always predict 'benign' and drive the full gated trajectory,
including the forced recovery. Must floor.

The hidden live stream is 143/228 benign = 0.627, which clears BAR = 0.62 in tests/grade.py
(and pass_bar_accuracy = 0.62 in the service config, so validate says clean too).
"""
import sys

from agent import Agent

CONSTANT_SERVE = '''"""No-skill serving: ignores the features and the model."""
import numpy as np


def predict(X):
    return np.ones(len(X), dtype=int)  # 1 = benign, the majority class
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", CONSTANT_SERVE)
a.cli("deploy")
a.cli("validate")                      # injected fault fires -> FAILED
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")                      # clean: 0.627 >= 0.62
a.cli("promote")
a.cli("submit")
