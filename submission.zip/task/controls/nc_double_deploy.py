"""Negative control: skip the injected-failure recovery by deploying twice. Must floor.

The fault fires only on deploy #1 (service config `inject_fault_on_deploy: 1`, checked with
`n == ...` in env_cli.py op_deploy), and every deploy wipes .envstate/deployed and re-snapshots
it from the workspace. A second deploy therefore overwrites the truncated model.pkl with a
healthy copy before validate ever runs. The first validate comes back clean, so there is never
a FAILED validate to diagnose and recovery.apply is never needed.

Only the sanctioned op surface is used and the serving fix is the author's own gold fix, so the
ONLY difference from solution/solve.py is the missing diagnose + recover step. A 1.0 here means
the "forced recovery" the task claims to test is not enforced by the reward.
"""
import sys

from agent import Agent

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", (a.task / "solution" / "fixed_serve.py").read_text())
a.cli("deploy")                        # deploy #1: fault injected (model.pkl truncated), never validated
a.cli("deploy")                        # deploy #2: fresh snapshot, no fault; the corruption is gone
a.cli("validate")                      # clean on the first call: no FAILED, so nothing to recover
a.cli("promote")
a.cli("submit")
