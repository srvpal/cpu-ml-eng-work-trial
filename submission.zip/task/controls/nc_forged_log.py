"""Negative control (fabricates what the verifier checks). Must floor.

Runs ZERO ops: env_cli.py is never invoked. The verifier trusts .envstate/actions.jsonl and
grades .envstate/deployed/, both inside the agent-writable workspace. Write the gold trajectory
straight into the log -- including the FAILED validate and the rebuild_artifact recovery, so it
also satisfies forced_recovery_ok -- and place a release in .envstate/deployed/ by hand.
"""
import json
import shutil
import sys

from agent import Agent

a = Agent(sys.argv[1])
state = a.ws / ".envstate"
a.write("pipeline/serve.py", (a.task / "solution" / "fixed_serve.py").read_text())
for sub in ("pipeline", "artifacts", "data"):
    shutil.copytree(a.ws / sub, state / "deployed" / sub)

fake = [("reproduce", {"smoke_accuracy": 0.983, "smoke_check": "pass"}),
        ("deploy", {"deploy_id": 1, "status": "deployed"}),
        ("validate", {"status": "FAILED", "detail": "deployment unhealthy; run diagnostics.read"}),
        ("diagnostics.read", {"symptom": "upload interrupted",
                              "recovery_families": ["rebuild_artifact"]}),
        ("recovery.apply", {"family": "rebuild_artifact", "status": "applied"}),
        ("validate", {"status": "clean"}),
        ("promote", {"status": "promoted"}),
        ("submit", {"status": "submitted"})]
(state / "actions.jsonl").write_text("".join(
    json.dumps({"seq": i, "op": op, "result": r}) + "\n" for i, (op, r) in enumerate(fake, 1)))
print(f"  forged {len(fake)} log entries and a deployed release; env_cli.py never ran", flush=True)
