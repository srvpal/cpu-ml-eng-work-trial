"""Positive control (correct but different): fix serving by standardising with the training
statistics that train.py writes to data/train_stats.json -- numerically the same transform as
artifacts/scaler.pkl (population mean/std of train.csv) -- then drive the full trajectory,
including the forced recovery. Should score 1.0.

validate runs the whole deployed tree (pipeline/, artifacts/, data/) and says clean, but
tests/grade.py stages only pipeline/serve.py and artifacts/, so the candidate cannot find data/.
"""
import sys

from agent import Agent

STATS_SERVE = '''"""Online scoring: standardise with the training-time statistics, never the live batch."""
import json
import pickle
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
_STATS = json.loads((ROOT / "data" / "train_stats.json").read_text())
MU = np.array([v["mean"] for v in _STATS.values()])
SD = np.array([v["std"] for v in _STATS.values()])


def predict(X):
    X = np.asarray(X, dtype=float)
    return MODEL.predict((X - MU) / SD).astype(int)
'''

a = Agent(sys.argv[1])
a.cli("inspect")
a.cli("reproduce")
a.write("pipeline/serve.py", STATS_SERVE)
a.cli("reproduce")                     # the fix still passes the smoke check
a.cli("deploy")
a.cli("validate")                      # injected fault fires -> FAILED
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")                      # clean
a.cli("promote")
a.cli("submit")
